<?php
class AccessibilityButtons extends pm_Hook_CustomButtons
{
    public function getButtons()
    {
        return [
            [
                'place' => [self::PLACE_ADMIN_TOOLS,self::PLACE_COMMON,self::PLACE_CUSTOMER_HOME,self::PLACE_ADMIN_NAVIGATION,self::PLACE_HEADER_NAVIGATION],
                'title' => 'Accessibility Button',
                'link' => 'https://example.com',
                'newWindow' => true,
            ],
        ];
    }

}
