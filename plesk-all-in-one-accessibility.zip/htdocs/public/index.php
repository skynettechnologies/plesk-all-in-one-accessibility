<?php
// Copyright 1999-2017. Plesk International GmbH.
require_once('pm/Loader.php');
pm_Loader::registerAutoload();

echo 'You can see it bypass authorization.';