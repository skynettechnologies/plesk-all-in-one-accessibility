<?php
// Copyright (c) 2025 Skynet Technologies USA LLC

$application = new pm_Application();
$application->run();
