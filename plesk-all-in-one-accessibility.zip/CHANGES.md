# 1.0.0

* [+] First release of the All in One Accessibility Plesk extension